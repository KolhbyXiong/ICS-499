package com.hgdiv.opendata.model;

/**
 * The type Genres.
 */
public class Genres extends Data<Genre> {

}
