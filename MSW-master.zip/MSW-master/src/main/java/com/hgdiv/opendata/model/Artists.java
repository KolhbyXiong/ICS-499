package com.hgdiv.opendata.model;

/**
 * The type Artists.
 */
public class Artists extends Data<Artist> {
    
}
