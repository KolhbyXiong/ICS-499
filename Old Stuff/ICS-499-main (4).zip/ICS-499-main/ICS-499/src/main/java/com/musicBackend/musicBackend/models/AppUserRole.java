package com.musicBackend.musicBackend.models;

public enum AppUserRole {
    USER,
    ADMIN
}
