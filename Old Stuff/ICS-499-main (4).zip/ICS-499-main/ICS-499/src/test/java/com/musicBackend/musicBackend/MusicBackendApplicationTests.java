package com.musicBackend.musicBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
